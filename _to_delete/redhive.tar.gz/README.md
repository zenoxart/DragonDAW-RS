# RedHiveFramework

**Red Hive** is a modular, server-driven enterprise framework written in Rust – the Rust rebuild of
Golden Hive. A long-running desktop host signs in, receives the modules assigned to the user as signed
packages, renders them in a dockable, keyboard-first shell and swaps them **while running** when a new
version is rolled out. Behind it, a set of small axum services handle identity, configuration, module
registry and delivery, staged rollouts, notifications, durable workflows and an AI agent with human
confirmation.

```
┌──────────────── Desktop host (egui) ────────────────┐        ┌──────────── Backend (axum + PostgreSQL) ────────────┐
│ shell · docking · palette · wheel · shortcuts       │  HTTP  │ api-gateway ─┬─ identity      ─ configuration        │
│ module loader (signed view packs) · hot-swap        │ ─────▶ │              ├─ module-registry ─ module-delivery     │
│ workflow inbox / designer / impact · AI panel       │  SSE   │              ├─ update-orchestrator (rollouts)       │
│ notifications · settings · profile                  │ ◀───── │              ├─ notification-point (outbox → SSE)   │
└─────────────────────────────────────────────────────┘        │              ├─ workflow-service ─ ai-agent          │
                                                               │              └─ module backends: documents, reports, │
                                                               │                 users                               │
                                                               └──────────────────────────────────────────────────────┘
```

## Features

| Area | What you get |
|---|---|
| **Monads** | `Error`/`Res<T>`, validators that collect every field error, problem-details over HTTP, railway-style use cases |
| **Identity** | JWT sign-in, PBKDF2 passwords with policy, roles → permissions (wildcards), avatars, delegated tokens for workflows/AI |
| **Configuration** | Tenant/user scoped settings with audit |
| **Modules** | Manifest with a versioned *contract surface*; dependency resolution; packages are ZIPs (manifest + view pack) signed with ECDSA P-256 and pinned on first use by the client |
| **Server-driven UI** | Modules ship *view packs* (dashboards, lists with filters/row actions, forms with lookups, report runners) – no native code is loaded, so hot-swap is safe |
| **Rollouts** | Publishing diffs the contract surface (compatible / migratable / review / breaking), runs a workflow impact analysis and starts a staged rollout Pilot → Broad → Complete, held automatically if workflows would break |
| **Hot-swap** | The client quiesces a module, verifies and loads the new version, re-registers views/commands/texts and rolls back on failure |
| **Notifications** | Transactional outbox → notification point → SSE with catch-up; subscriber cursors; optional Windows push (WNS) and OS toasts |
| **Workflows** | Durable engine: input, choice, review, command, module step, wait-for-event, approval, AI task, sub-workflow; manual/command/event/schedule/condition triggers; safe expression language; recorder; designer; impact analysis with automatic migration |
| **AI agent** | Rules provider (offline) or any OpenAI-compatible endpoint; autonomy levels per workflow; critical steps are confirmed by a person and then executed *as that person*; guardrails and full audit; global kill switch |
| **Shell** | VS-style docking, detachable windows, command palette (Ctrl+Shift+P), navigation wheel (hold Ctrl+Tab), chorded shortcuts with editor and presets, cheat sheet, English/German/pseudo-locale, themes, zoom |

## Repository layout

```
crates/shared/monads           Error, Res, Validator
crates/shared/contracts        DTOs, manifests, contract diff, view packs, workflow model + expression language
crates/backend/core            hosting, db, security, http helpers, outbox, audit
crates/backend/*               api-gateway and the platform services
modules/<name>/                manifest.json, client/views.json, backend/ (axum service), workflows/ (templates)
crates/client/framework        client services: api, i18n, commands, shortcuts, docking, modules, hot-swap, views, workflows
crates/client/host             the desktop app (`redhive`)
tools/redhive-cli              pack / sign / upload / publish modules
deployment/docker              Dockerfile, docker-compose.yml, database schema + demo data
deployment/local               run all services without Docker, end-to-end smoke test
docs/                          architecture and module guide
```

## Quick start

### 1. Backend with Docker

```bash
cd deployment/docker
cp .env.example .env          # change the secrets
docker compose up --build
```

The gateway listens on `http://localhost:8080`. Demo users: `admin`, `maria.huber`, `elena.rossi`,
`lukas.berger`, `sophie.wagner` – password `RedHive!2026`.

### 2. Backend without Docker

```bash
createuser redhive -P && createdb -O redhive redhive        # password: redhive
psql -U redhive -d redhive -f deployment/docker/database/01-schema.sql
psql -U redhive -d redhive -f deployment/docker/database/02-demo-data.sql
cargo build
./deployment/local/run-services.sh                          # Windows: deployment\local\run-services.ps1
python3 deployment/local/smoke-test.py                      # end-to-end check
```

### 3. Desktop client

```bash
cargo run -p redhive-host --release -- --server http://localhost:8080
```

`redhive://navigate?target=<view>&parameter=<id>` deep links (as sent by notifications) can be passed
as argument.

#### Building on Windows

The default Rust toolchain on Windows (`x86_64-pc-windows-msvc`) needs the **Visual Studio C++ build
tools** with the *x64* libraries. If linking fails with `LNK1104: cannot open file 'msvcrt.lib'`, the
MSVC installation is incomplete – either repair it:

```powershell
& "C:\Program Files (x86)\Microsoft Visual Studio\Installer\setup.exe" repair --installPath "C:\Program Files\Microsoft Visual Studio\18\Community" --passive --norestart
```

(make sure the workload *Desktop development with C++* with *MSVC x64/x86 build tools* and a *Windows SDK*
is selected), or use the GNU toolchain instead:

```powershell
rustup toolchain install stable-x86_64-pc-windows-gnu
rustup default stable-x86_64-pc-windows-gnu
```

On Windows the client stores the session token in the Windows Credential Manager and shows native toasts.

## Writing a module

A module is a folder with a manifest, a view pack and (optionally) a backend service and workflow
templates. See [docs/MODULES.md](docs/MODULES.md). Publish it with the CLI:

```bash
TOKEN=$(cargo run -q -p redhive-cli -- login --server http://localhost:8080 --user admin --password 'RedHive!2026')
cargo run -p redhive-cli -- publish modules/document-management --server http://localhost:8080 --token "$TOKEN"
```

Publishing classifies the change against the running version, analyses every workflow that uses the
module and starts a staged rollout; connected clients swap the module without a restart.

## Configuration

| Variable | Meaning |
|---|---|
| `DATABASE_URL` | PostgreSQL connection |
| `REDHIVE__PORT` | listen port (default 8080) |
| `REDHIVE__JWT_KEY` | HMAC key for user tokens |
| `REDHIVE__INTERNAL_KEY` | shared key for `/internal/*` service calls |
| `REDHIVE__SERVICE__<NAME>` | base URL of another service (default `http://<name>:8080`) |
| `REDHIVE__MODULES_DIR` | folder with module sources (seeds manifests, packages and workflow templates) |
| `REDHIVE__SIGNING_KEY` | PKCS#8 PEM of the package signing key (generated and stored if empty) |
| `REDHIVE__AI__PROVIDER` / `ENDPOINT` / `API_KEY` / `MODEL` / `REVIEW_LIMIT` | AI agent |
| `REDHIVE__SUBSCRIBERS` | notification subscribers (`workflow-service=/internal/events`) |
| `REDHIVE__WNS__PACKAGE_SID` / `CLIENT_SECRET` | Windows push notifications |
| `REDHIVE__RATE_LIMIT_PER_MINUTE` | gateway rate limit per user/IP |
| `REDHIVE__LOG_FORMAT` | `json` or text |

## Development

```bash
cargo test --workspace           # unit + contract tests (manifests, view packs, templates, glyph coverage)
cargo clippy --workspace
```

More: [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

## License

Apache-2.0 – see [LICENSE](LICENSE).
